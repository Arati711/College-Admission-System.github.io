# CollegeAdmissionSystem
This website is developed using ASP.NET MVC and Entity Framework. In this students can apply for various courses and also admin can see all the received applications.
![IMG-20210722-WA0030](https://user-images.githubusercontent.com/87900572/126868773-6a8ba45f-7518-4597-abdd-9efd8deb84cf.jpg)


![IMG-20210722-WA0040](https://user-images.githubusercontent.com/87900572/126868790-dc469a7c-7cf4-4b62-97b8-30289857744c.jpg)


![IMG-20210722-WA0041](https://user-images.githubusercontent.com/87900572/126868792-ea9f8958-fdb7-48bc-85d2-41ae2a4387b3.jpg)


![IMG-20210722-WA0039](https://user-images.githubusercontent.com/87900572/126868796-d999427c-facc-4912-aef5-1616c4d62549.jpg)
